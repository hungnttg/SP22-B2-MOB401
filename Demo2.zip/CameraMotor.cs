﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMotor : MonoBehaviour
{
    //khai báo biến
    private Transform lookAt;//nhan vat
    private Vector3 startOffset;//khoang cach offset
    private Vector3 moveVector;//vector di chuyen
    private float transition = 0.0f;//khoang bien doi
    private float animationDuration = 3.0f;//thoi gian animation
    private Vector3 animationOffset = new Vector3(0, 5, 5);//khoi tao vector

    void Start()
    {
        //anh xa
        lookAt = GameObject.FindGameObjectWithTag("Player").transform;
        startOffset = transform.position - lookAt.position;
    }


    void Update()
    {
        moveVector = lookAt.position + startOffset;
        //theo truc X
        moveVector.x = 0f;
        //theo truc Y
        moveVector.y = Mathf.Clamp(moveVector.y, 3, 5);
        if (transition > 1.0f)
        {
            transform.position = moveVector;//cap nhat vi tri cua camera theo nhan vat
        }
        else
        {
            transform.position = Vector3.Lerp(moveVector + animationOffset, moveVector, transition);
            transition += Time.deltaTime * 1 / animationDuration;
            transform.LookAt(lookAt.position + Vector3.up);
        }
    }
}
