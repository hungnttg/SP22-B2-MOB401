﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DeadMenu : MonoBehaviour
{
    public Text scoreText;
    public Image backgroundImage;
    private float transition = 0.0f;
    void Start()
    {
        gameObject.SetActive(false);//deathMenu ban dau khong hien thi
    }


    void Update()
    {
        if (!isShowned)
            return;
        transition += Time.deltaTime;
        //chuyen doi mau sac
        backgroundImage.color = Color.Lerp(new Color(0,0,0),Color.green,transition);
    }
    public bool isShowned = false;
    public void ToggleEndMenu(float score)
    {
        gameObject.SetActive(true);
        scoreText.text = ((int)score).ToString();//hien thi diem
        isShowned = true;
    }
    public void RestartGame()
    {
        SceneManager.LoadScene("SampleScene");//load lai scene
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
