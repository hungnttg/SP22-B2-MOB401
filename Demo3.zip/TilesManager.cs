﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilesManager : MonoBehaviour
{
    //khai bao cac bien
    public GameObject[] tilePrefabs;//mang dia hinh
    private int lastPrefabIndex = 0;//chi so cuoi
    private Transform player;//nhan vat
    private float spawnZ = 0.0f;
    private List<GameObject> activeTiles;//dia hinh dang active
    private float safeZone = 15.0f;//khoang thi truong camera nhin thay
    private float tileLength = 10.0f;//chieu dai 1 dia hinh
    private int tilesOnScreen = 3;//so luong dia hinh cung hien thi
    void Start()
    {
        activeTiles = new List<GameObject>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
        for (int i = 0; i < tilesOnScreen; i++)
        {
            if (i < 2)
                SinhDiaHinh(0);
            else
                SinhDiaHinh();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (player.position.z - safeZone > (spawnZ - tilesOnScreen * tileLength))
        {
            SinhDiaHinh();
            XoaDiaHinh();
        }
    }
    private void XoaDiaHinh()
    {
        Destroy(activeTiles[0]);
        activeTiles.RemoveAt(0);
    }
    private void SinhDiaHinh(int prefabIndex = -1)
    {
        GameObject gameObject;
        if (prefabIndex == -1)
            gameObject = Instantiate(tilePrefabs[RandomPrefabIndex()]) as GameObject;
        else
            gameObject = Instantiate(tilePrefabs[prefabIndex]) as GameObject;
        gameObject.transform.SetParent(transform);
        gameObject.transform.position = Vector3.forward * spawnZ;
        spawnZ += tileLength;
        activeTiles.Add(gameObject);
    }
    private int RandomPrefabIndex()//lay 1 dia hinh ngau nhien
    {
        if (tilePrefabs.Length <= 1)
        {
            return 0;
        }
        int randomIndex = lastPrefabIndex;
        while (randomIndex == lastPrefabIndex)
        {
            randomIndex = Random.Range(0, tilePrefabs.Length);//ham random
        }
        lastPrefabIndex = randomIndex;
        return randomIndex;
    }
}
