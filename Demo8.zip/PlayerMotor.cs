﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    private float speed = 5.0f;//toc do
    private CharacterController controller;//doi tuong dieu khien di chuyen
    private float verticalVelocity = 0.0f;
    private float gravity = 10.0f;
    Vector3 moveVector;//vecto di chuyen
    private float animationDuration = 3.0f;//thoi gian hoat hinh
    void Start()
    {
        //anh xa
        controller = GetComponent<CharacterController>();
    }
    private bool isDead = false;
    private void Death()
    {
        isDead = true;
        GetComponent<Score>().OnDeath();//goi OnDeath trong file Score
    }
    //xu ly va cham
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.transform.tag == "Coin")//neu va cham voi coi
        {
            Destroy(hit.gameObject);
        }

       // if (hit.point.z > transform.position.z + controller.radius)//khi va cham
           // Death();//nhan vat chet


    }
    
    void Update()
    {
        if (isDead)
            return;
        //xu ly di chuyen
        if(Time.time < animationDuration)
        {
            //di chuyen nhan vat
            controller.Move(Vector3.forward * speed * Time.deltaTime);
            return;
        }
        moveVector = Vector3.zero;
        if(controller.isGrounded)//kiem tra va cham vao san
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        //dieu khien di chuyen
        moveVector.x = Input.GetAxisRaw("Horizontal") * speed;//truc x: trai, phai
        //moveVector.y = verticalVelocity;//truc y: len, xuong
        moveVector.z = speed;//truc z: tien, lui

        if (Input.GetKey(KeyCode.Space))
        {
            moveVector = Vector3.Lerp(moveVector,
                new Vector3(moveVector.x, 50, moveVector.z), Time.deltaTime);
        }
        else
        {
            moveVector = Vector3.Lerp(moveVector,
                new Vector3(moveVector.x, -20, moveVector.z), Time.deltaTime);

        }

        controller.Move(moveVector*Time.deltaTime);
    }
    public void SetSpeed(float delta)//ham tang toc
    {
        speed = 5.0f + delta;
    }
}
