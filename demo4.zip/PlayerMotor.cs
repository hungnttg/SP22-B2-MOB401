﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    private float speed = 5.0f;//toc do
    private CharacterController controller;//doi tuong dieu khien di chuyen
    private float verticalVelocity = 0.0f;
    private float gravity = 10.0f;
    Vector3 moveVector;//vecto di chuyen
    private float animationDuration = 3.0f;//thoi gian hoat hinh
    void Start()
    {
        //anh xa
        controller = GetComponent<CharacterController>();
    }
    void Update()
    {
        //xu ly di chuyen
        if(Time.time < animationDuration)
        {
            //di chuyen nhan vat
            controller.Move(Vector3.forward * speed * Time.deltaTime);
            return;
        }
        moveVector = Vector3.zero;
        if(controller.isGrounded)//kiem tra va cham vao san
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        //dieu khien di chuyen
        moveVector.x = Input.GetAxisRaw("Horizontal") * speed;//truc x: trai, phai
        moveVector.y = verticalVelocity;//truc y: len, xuong
        moveVector.z = speed;//truc z: tien, lui
        controller.Move(moveVector*Time.deltaTime);
    }
    public void SetSpeed(float delta)//ham tang toc
    {
        speed = 5.0f + delta;
    }
}
