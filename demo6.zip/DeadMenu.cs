﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeadMenu : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        gameObject.SetActive(false);//deathMenu ban dau khong hien thi
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ToggleEndMenu(float score)
    {
        gameObject.SetActive(true);
    }
}
