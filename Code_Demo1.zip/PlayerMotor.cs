﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    private float speed = 5.0f;//van toc
    private CharacterController controller;//doi tuong dieu khien di chuyen
    private float verticalVelocity = 0.0f;
    private float gravity = 10.0f;
    Vector3 moveVector;//vector di chuyen
    private float animationDuration = 3.0f;
    void Start()
    {
        controller = GetComponent<CharacterController>();//anh xa
    }
    void Update()
    {
        //xu ly phan di chuyen cua nhan vat
        if(Time.time < animationDuration)
        {
            controller.Move(Vector3.forward * speed * Time.deltaTime);
            return;
        }
        moveVector =  Vector3.zero;//khoi tao vector
        if(controller.isGrounded)//neu chay tren san
        {
            verticalVelocity = 0.5f;
        }
        else
        {
            verticalVelocity -= gravity*Time.deltaTime;//tru gia toc trong truong
        }
        //dieu khien
        moveVector.x = Input.GetAxisRaw("Horizontal")* speed;//sang trai, phai (cua truc x)
        moveVector.y = verticalVelocity;// truc y: len, xuong
        moveVector.z = speed;//truc z: tien, lui
        controller.Move(moveVector*Time.deltaTime);
    }
}
